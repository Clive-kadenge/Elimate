# Context

Developer context for Elimate app.