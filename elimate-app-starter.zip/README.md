# Elimate App

Starter project for Elimate.